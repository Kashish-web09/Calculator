let display = document.getElementById('display');
let currentInput = '';

function clearDisplay() {
  currentInput = "";
  display.textContent = "0";
}

function deleteLast() {
  currentInput = currentInput.slice(0, -1);
  display.textContent = currentInput || "0";
}

function appendNumber(number) {
  if (currentInput === "0" && number !== ".") {
    currentInput = "";
  }
  currentInput += number;
  display.textContent = currentInput;
}

function appendOperator(operator) {
  if (currentInput === "") return;
  const lastChar = currentInput.slice(-1);
  if (["+", "-", "*", "/", "%"].includes(lastChar)) return;
  currentInput += operator;
  display.textContent = currentInput;
}

function calculateResult() {
  try {
    let expression = currentInput.replace(/%/g, "/100");
    let result = eval(expression);
    display.textContent = result;
    currentInput = result.toString();
  } catch (error) {
    display.textContent = "Error";
    currentInput = "";
  }
}
